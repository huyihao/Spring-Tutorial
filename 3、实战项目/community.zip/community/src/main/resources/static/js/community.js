function comment() {
    var questionId = $("#questionId").val();
    var comment = $("#commentText").val();
    console.log(questionId);
    console.log(comment);
    $.ajax({
        type: "POST",
        contentType : "application/json",
        url: "/comment",
        data: JSON.stringify({
            "parentId" : questionId,
            "content" : comment,
            "type" : 1
        }),
        success: function (response) {
            console.log(response);
            if (response.code != 0) {
                if (response.code == 2002) {
                    var isAccepted = confirm(response.message);
                    if (isAccepted) {
                        window.open("https://github.com/login/oauth/authorize?client_id=ce46b85af14a2d21447b&redirect_uri=http://localhost:8080/callback&scope=user&state=2");
                        window.localStorage.setItem("closable", true);
                    }
                } else {
                    alert(response.message);
                }
            } else {
                $("#commentText").val("");
            }
        },
        dataType: "json"
    });
}