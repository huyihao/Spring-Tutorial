/**
 * 提交评论
 **/
function comment() {
    var questionId = $("#questionId").val();
    var comment = $("#commentText").val();
    $.ajax({
        type: "POST",
        contentType : "application/json",
        url: "/comment",
        data: JSON.stringify({
            "parentId" : questionId,
            "content" : comment,
            "type" : 1
        }),
        success: function (response) {
            console.log(response);
            if (response.code != 0) {
                if (response.code == 2002) {
                    var isAccepted = confirm(response.message);
                    if (isAccepted) {
                        window.open("https://github.com/login/oauth/authorize?client_id=ce46b85af14a2d21447b&redirect_uri=http://localhost:8080/callback&scope=user&state=2");
                        window.localStorage.setItem("closable", true);
                    }
                } else {
                    alert(response.message);
                }
            } else {
                var userAvatar = $("#userAvatar")[0].src;
                var userName = $("#userName").text();

                var template = $("#comment-template").children(".media");
                template.find(".small-avatar").attr("src", userAvatar);
                template.find(".media-heading").text(userName);
                template.find(".comment-text").text(comment);
                template.find(".pull-right").text(getFormatDate());
                $("#comment-list").append($("#comment-template").html());
                $("#commentText").val("");

                // 评论总数加1
                var commentCount = parseInt($("#commentCount").text());
                $("#commentCount").text(commentCount + 1);
            }
        },
        dataType: "json"
    });
}

function getFormatDate(){
    var nowDate = new Date();
    var year = nowDate.getFullYear();
    var month = nowDate.getMonth() + 1 < 10 ? "0" + (nowDate.getMonth() + 1) : nowDate.getMonth() + 1;
    var date = nowDate.getDate() < 10 ? "0" + nowDate.getDate() : nowDate.getDate();
    var hour = nowDate.getHours()< 10 ? "0" + nowDate.getHours() : nowDate.getHours();
    var minute = nowDate.getMinutes()< 10 ? "0" + nowDate.getMinutes() : nowDate.getMinutes();
    var second = nowDate.getSeconds()< 10 ? "0" + nowDate.getSeconds() : nowDate.getSeconds();
    return year + "-" + month + "-" + date;
}

/**
 * 切换二级评论
 */
function toggleSubComments(e) {
    var id = e.getAttribute("data-id");
    var subComments = $("#subComments-" + id);
    console.log(id);
    console.log(subComments);
    if (subComments.hasClass("in")) {
        subComments.removeClass("in");
    } else {
        subComments.addClass("in");
    }
}