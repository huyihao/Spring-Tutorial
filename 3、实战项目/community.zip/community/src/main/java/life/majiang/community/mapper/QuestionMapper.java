package life.majiang.community.mapper;

import life.majiang.community.model.Question;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface QuestionMapper {

    @Insert("insert into question (title, description, gmt_create, gmt_modified, creator, tag) values (#{title}, #{description}, #{gmtCreate}, #{gmtModified}, #{creator}, #{tag})")
    void insert(Question question);

    // 查询所有问题列表
    @Select("select * from question")
    List<Question> list();

    // 查询分页问题列表
    @Select("select * from question limit #{offset}, #{size}")
    List<Question> listPage(@Param("offset") Integer offset, @Param("size") Integer size);

    // 获取总记录条数
    @Select("select count(1) from question")
    Integer count();
}