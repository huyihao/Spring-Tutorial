package life.majiang.community.controller;

import life.majiang.community.dto.QuestionDTO;
import life.majiang.community.mapper.QuestionMapper;
import life.majiang.community.model.Question;
import life.majiang.community.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class ProfileController {

    @Autowired
    QuestionService questionService;

    @GetMapping("/profile")
    public String profile(HttpServletRequest request,
                          Model model) {
        if (request.getSession() != null && request.getSession().getAttribute("user") == null) {
            return "redirect:/";
        }

        List<QuestionDTO> questions = questionService.list();
        model.addAttribute("questions", questions);

        return "profile";
    }

}
