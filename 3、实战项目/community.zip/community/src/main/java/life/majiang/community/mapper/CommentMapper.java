package life.majiang.community.mapper;

import life.majiang.community.model.Comment;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface CommentMapper {

    @Insert("insert into comment(parent_id, type, commentator, content, like_count, gmt_create, gmt_modified) values (#{parentId}, #{type}, #{commentator}, #{content}, #{likeCount}, #{gmtCreate}, #{gmtModified})")
    public Integer insert(Comment comment);

    @Select("select * from comment where id = #{id}")
    Comment selectById(@Param("id") Long parentId);
}
