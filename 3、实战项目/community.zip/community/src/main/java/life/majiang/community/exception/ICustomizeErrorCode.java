package life.majiang.community.exception;

public interface ICustomizeErrorCode {

    Integer getCode();
    String getMessage();

}
